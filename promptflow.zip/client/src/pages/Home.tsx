import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  BookOpenText,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Command,
  GitBranch,
  GraduationCap,
  Headphones,
  Menu,
  MessageCircle,
  MoveUpRight,
  PanelsTopLeft,
  ShieldCheck,
  Sparkles,
  X,
  Zap,
} from "lucide-react";
import WorkflowPreview from "@/components/site/WorkflowPreview";
import {
  audiences,
  faqItems,
  heroPrompt,
  heroSteps,
  howSteps,
  plans,
  scenarios,
  templates,
  type WorkflowStep,
} from "@/components/site/siteContent";

const navItems = [
  { label: "How it works", href: "#how" },
  { label: "Support automation", href: "#support" },
  { label: "Solutions", href: "#solutions" },
  { label: "Templates", href: "#templates" },
  { label: "Pricing", href: "#pricing" },
  { label: "Customers", href: "#customers" },
];

function Brand({ inverse = false }: { inverse?: boolean }) {
  return (
    <a className={`brand${inverse ? " brand--inverse" : ""}`} href="#home" aria-label="PromptFlow home">
      <svg className="brand__mark" viewBox="0 0 40 40" fill="none" aria-hidden="true">
        <path d="M9 10.5v19M9 20h9.5m0 0 8-8m-8 8 8 8m0-16H31m-4.5 16H31" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="9" cy="10" r="3" fill="currentColor" />
        <circle cx="31" cy="12" r="3" fill="currentColor" />
        <circle cx="31" cy="28" r="3" fill="currentColor" />
        <circle cx="18.5" cy="20" r="2.4" fill="var(--brand-mark-center, #e7ad62)" />
      </svg>
      <span>Prompt<span>Flow</span></span>
    </a>
  );
}

function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
}: {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
}) {
  return (
    <div className={`section-heading section-heading--${align}`}>
      <p className="eyebrow"><span />{eyebrow}</p>
      <h2>{title}</h2>
      {description && <p className="section-heading__description">{description}</p>}
    </div>
  );
}

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="site-header__inner">
        <Brand />
        <nav id="main-menu" className={`main-nav${menuOpen ? " main-nav--open" : ""}`} aria-label="Main navigation">
          {navItems.map(item => <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)}>{item.label}</a>)}
          <a className="mobile-nav-cta" href="#start" onClick={() => setMenuOpen(false)}>Start free <ArrowUpRight size={15} /></a>
        </nav>
        <div className="site-header__actions">
          <a className="header-demo-link" href="#demo">Book a demo</a>
          <a className="button button--small button--primary" href="#start">Start free <ArrowUpRight size={15} /></a>
        </div>
        <button
          className="menu-toggle"
          type="button"
          aria-expanded={menuOpen}
          aria-controls="main-menu"
          aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
          onClick={() => setMenuOpen(open => !open)}
        >
          {menuOpen ? <X size={21} /> : <Menu size={21} />}
        </button>
      </div>
    </header>
  );
}

function Hero() {
  const [typedPrompt, setTypedPrompt] = useState("");
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setTypedPrompt(heroPrompt);
      return;
    }
    let cursor = 0;
    const timer = window.setInterval(() => {
      cursor = Math.min(cursor + 2, heroPrompt.length);
      setTypedPrompt(heroPrompt.slice(0, cursor));
      if (cursor >= heroPrompt.length) window.clearInterval(timer);
    }, 18);
    return () => window.clearInterval(timer);
  }, []);
  return (
    <section className="hero" id="home">
      <div className="hero__grain" aria-hidden="true" />
      <div className="wrap hero__layout">
        <div className="hero__copy">
          <p className="eyebrow"><span /> PROMPT-TO-WORKFLOW AI BUILDER</p>
          <h1>Stop building workflows.<br /><em>Start describing them.</em></h1>
          <p className="hero__subhead">Type what your customer support should do. PromptFlow builds the full automation, and you review it before anything goes live.</p>
          <div className="hero__actions">
            <a className="button button--primary" href="#start">Start free <ArrowUpRight size={17} /></a>
            <a className="button button--outline" href="#demo">Book a demo <ArrowRight size={16} /></a>
          </div>
          <div className="hero__trust"><span className="hero__trust-check"><Check size={13} /></span><span>No card needed</span><i /> <span>Your first generation is free</span></div>
          <div className="hero__proofline"><span className="proof-orbit"><GitBranch size={15} /></span><span>Describe it in plain language.<br /><strong>Keep every decision in your hands.</strong></span></div>
        </div>
        <div className="hero__visual">
          <div className="hero__visual-glow" aria-hidden="true" />
          <div className="prompt-board">
            <div className="prompt-board__top"><span className="window-dots"><i /><i /><i /></span><span className="prompt-board__label"><Command size={13} /> YOUR PROMPT</span><span className="prompt-board__live"><span /> LIVE PREVIEW</span></div>
            <div className="prompt-board__body">
              <span className="prompt-board__quote">“</span>
              <p aria-label={heroPrompt}><span aria-hidden="true">{typedPrompt}</span></p>
              <span className="prompt-board__cursor" aria-hidden="true" />
            </div>
            <div className="prompt-board__footer"><span><Sparkles size={14} /> Plain language in</span><span className="prompt-board__arrow"><ArrowDownRight size={17} /></span><span>Reviewable workflow out</span></div>
            <div className="hero__workflow"><WorkflowPreview steps={heroSteps} title="Customer support" subtitle="Your process, made visible" /></div>
          </div>
          <div className="hero-note hero-note--top"><span className="hero-note__icon"><ShieldCheck size={17} /></span><span><strong>Human approval</strong><small>Right where you need it</small></span></div>
          <div className="hero-note hero-note--bottom"><span className="hero-note__icon hero-note__icon--mint"><Zap size={17} /></span><span><strong>Ready to test</strong><small>Nothing live without review</small></span><span className="hero-note__status" /></div>
          <span className="hero-orbit hero-orbit--one" aria-hidden="true" />
          <span className="hero-orbit hero-orbit--two" aria-hidden="true" />
        </div>
      </div>
      <div className="hero__edge wrap"><span>ONE PROMPT. A CLEARER WAY TO WORK.</span><a href="#how">See how it works <ArrowDownRight size={14} /></a></div>
    </section>
  );
}

function Comparison() {
  return (
    <section className="comparison section-pad">
      <div className="wrap comparison__layout">
        <div className="comparison__intro">
          <p className="eyebrow"><span /> THE BETTER STARTING POINT</p>
          <h2>The slow part of automation is the building.</h2>
          <p>Agencies already know AI workflows save time. Getting one built is what eats the week.</p>
          <a className="text-link" href="#how">A simpler way to start <ArrowUpRight size={15} /></a>
        </div>
        <div className="comparison__cards">
          <article className="comparison-card comparison-card--muted">
            <div className="comparison-card__top"><span>01 / BUILD BY HAND</span><span className="comparison-card__icon"><PanelsTopLeft size={17} /></span></div>
            <p className="comparison-card__time">About <strong>2 days</strong></p>
            <p>Map the process, drag nodes, connect tools, match fields, test edge cases, repeat for the next client.</p>
            <div className="comparison-card__line"><span /></div>
          </article>
          <article className="comparison-card comparison-card--accent">
            <div className="comparison-card__top"><span>02 / DESCRIBE IT</span><span className="comparison-card__icon"><Sparkles size={17} /></span></div>
            <p className="comparison-card__time">About <strong>5 minutes</strong></p>
            <p>Write the process in plain language, read the result, adjust a step, test, deploy.</p>
            <div className="comparison-card__line"><span /></div>
          </article>
          <p className="fine-print comparison__note">Illustrative times only. Replace with measured pilot results before launch.</p>
        </div>
      </div>
    </section>
  );
}

function ThreeSteps() {
  const steps = [
    { n: "01", title: "Describe the process", text: "“Answer common questions, escalate angry customers to a person, log every ticket.”", icon: <MessageCircle size={19} /> },
    { n: "02", title: "Review what was built", text: "Every step is visible and editable. Add a human approval wherever you want one.", icon: <GitBranch size={19} /> },
    { n: "03", title: "Test, then deploy", text: "Run sample conversations in test mode. Go live when the results look right.", icon: <MoveUpRight size={19} /> },
  ];
  return (
    <section className="steps-section section-pad" id="how">
      <div className="wrap">
        <SectionHeading eyebrow="FROM A SENTENCE TO A SAFER SYSTEM" title="How PromptFlow works." description="From a sentence to a tested workflow, with a review step in the middle." />
        <div className="three-steps">
          {steps.map((step, i) => <article className="three-step" key={step.n}>
            <div className="three-step__head"><span className="three-step__icon">{step.icon}</span><span className="three-step__number">{step.n}</span></div>
            <h3>{step.title}</h3><p>{step.text}</p>
            {i < steps.length - 1 && <span className="three-step__connector" aria-hidden="true"><ArrowRight size={16} /></span>}
          </article>)}
        </div>
        <div className="how-detail">
          <div className="how-detail__list">
            {howSteps.map(step => <article className="how-step" key={step.number}>
              <span className="how-step__number">{step.number}</span><div><h3>{step.title}</h3><p>{step.text}</p></div>
            </article>)}
          </div>
          <div className="prompt-compare">
            <div className="prompt-compare__head"><span><Command size={14} /> THE DETAILS MAKE THE DIFFERENCE</span><span className="prompt-compare__badge">PROMPT CRAFT</span></div>
            <div className="prompt-example prompt-example--good"><div className="prompt-example__label"><span /> SPECIFIC · GOOD</div><p>“When a WhatsApp message mentions a refund, check the order status, reply with the policy, and ask a person to approve anything over 5,000.”</p><div className="prompt-example__result"><Check size={14} /> Clear channel, rule, and checkpoint</div></div>
            <div className="prompt-example prompt-example--weak"><div className="prompt-example__label"><span /> TOO VAGUE · WEAK</div><p>“Make my support better.”</p></div>
            <div className="prompt-compare__footer"><ShieldCheck size={16} /><span>Review every step before anything goes live.</span></div>
          </div>
        </div>
        <div className="integration-strip"><div className="integration-strip__label">WORKS WITH YOUR<br /><strong>EVERYDAY CHANNELS</strong></div><div className="integration-pills">{["Email", "WhatsApp", "Website chat", "CRM", "Helpdesk", "Spreadsheets", "Slack"].map((name, i) => <span key={name} className="integration-pill"><i>{["@", "◉", "⌘", "◈", "▣", "▦", "#"][i]}</i>{name}</span>)}</div><p className="fine-print">Confirm the final integration list before publishing.</p></div>
      </div>
    </section>
  );
}

function SupportAutomation() {
  const [activeId, setActiveId] = useState(scenarios[0].id);
  const active = scenarios.find(item => item.id === activeId) ?? scenarios[0];
  const benefits = ["First replies go out in seconds, at any hour.", "Repeat questions stop reaching your agents.", "Angry or urgent customers reach a person quickly.", "Every ticket is logged with a priority, without anyone typing it."];
  return (
    <section className="support-section section-pad" id="support">
      <div className="support-section__grid" aria-hidden="true" />
      <div className="wrap support-section__content">
        <div className="support-section__intro">
          <p className="eyebrow eyebrow--light"><span /> THE HERO USE CASE</p>
          <h2>Customer support,<br /><em>from one prompt.</em></h2>
          <p>Choose a real support moment. See the plain-language request—and the workflow it can become.</p>
        </div>
        <div className="scenario-tabs" role="tablist" aria-label="Support automation scenarios">
          {scenarios.map((scenario, i) => <button key={scenario.id} type="button" role="tab" id={`tab-${scenario.id}`} aria-controls="scenario-panel" aria-selected={activeId === scenario.id} className={activeId === scenario.id ? "is-active" : ""} onClick={() => setActiveId(scenario.id)}><span>0{i + 1}</span>{scenario.title}<ArrowUpRight size={14} /></button>)}
        </div>
        <div className="scenario-panel" role="tabpanel" id="scenario-panel" aria-labelledby={`tab-${active.id}`}>
          <div className="scenario-panel__prompt"><div className="scenario-panel__label"><Command size={15} /> THE PROMPT</div><p>{active.prompt}</p><a href="#start" className="scenario-panel__try">Try this prompt free <ArrowUpRight size={15} /></a></div>
          <div className="scenario-panel__workflow"><WorkflowPreview steps={active.steps} title={active.title} subtitle="Sample workflow · review before launch" /></div>
        </div>
        <div className="support-benefits"><div className="support-benefits__label">WHAT CHANGES<br />FOR THE TEAM</div>{benefits.map((benefit, i) => <div className="support-benefit" key={benefit}><span>0{i + 1}</span>{benefit}</div>)}</div>
      </div>
    </section>
  );
}

function Solutions() {
  const Icons = [Command, GraduationCap, Zap, Headphones];
  return (
    <section className="solutions-section section-pad" id="solutions">
      <div className="wrap">
        <SectionHeading eyebrow="MADE FOR THE PEOPLE DOING THE WORK" title="A better workflow looks different for everyone." description="Start with the work your team already understands. Build it around the way you serve people." />
        <div className="solutions-list">
          {audiences.map((item, i) => {
            const Icon = Icons[i];
            const actionHref = item.id === "freelancer" ? "#start" : item.id === "institute" ? "#demo" : "#demo";
            return <article className="solution-row" key={item.id}>
              <div className="solution-row__index">0{i + 1}</div>
              <div className="solution-row__audience"><span className="solution-row__icon"><Icon size={19} /></span><span>{item.short}</span></div>
              <div className="solution-row__main"><h3>{item.title}</h3><p>{item.description}</p><ul>{item.benefits.map(benefit => <li key={benefit}><Check size={14} />{benefit}</li>)}</ul></div>
              <div className="solution-row__action"><span className="solution-row__plan">{item.plan} plan</span><a href={actionHref}>{item.action}<ArrowUpRight size={15} /></a></div>
            </article>;
          })}
        </div>
      </div>
    </section>
  );
}

function Templates() {
  const filters = ["All", "Support", "Agency", "Education"];
  const [filter, setFilter] = useState("All");
  const filtered = useMemo(() => filter === "All" ? templates : templates.filter(item => item.category === filter), [filter]);
  const cardIcons = [MessageCircle, ShieldCheck, CircleHelp, Command, Clock3, BookOpenText];
  return (
    <section className="templates-section section-pad" id="templates">
      <div className="wrap">
        <div className="templates-heading"><div><SectionHeading eyebrow="A QUICKER PLACE TO BEGIN" title="Start with a pattern that works." description="Pick a starting point. Make it yours. Keep the parts that already fit." /></div><a className="text-link templates-heading__link" href="#start">Describe your own <ArrowUpRight size={15} /></a></div>
        <div className="template-toolbar"><div className="filter-group" role="group" aria-label="Filter templates by category">{filters.map(item => <button type="button" key={item} className={filter === item ? "is-active" : ""} aria-pressed={filter === item} onClick={() => setFilter(item)}>{item}</button>)}</div><span>{filtered.length} templates <span className="template-toolbar__dot">·</span> curated to get you moving</span></div>
        <div className="template-grid">{filtered.map((item, index) => {
          const Icon = cardIcons[templates.indexOf(item)];
          return <article className="template-card" key={item.title}>
            <div className="template-card__top"><span className="template-card__icon"><Icon size={18} /></span><span className="template-card__category">{item.category}</span><span className="template-card__time"><Clock3 size={13} />{item.saved}</span></div>
            <h3>{item.title}</h3><p>{item.description}</p>
            <a href="#start" className="template-card__link">Use this template <ArrowUpRight size={15} /></a>
            <span className="template-card__number">0{index + 1}</span>
          </article>;
        })}</div>
      </div>
    </section>
  );
}

function Pricing() {
  const [annual, setAnnual] = useState(false);
  return (
    <section className="pricing-section section-pad" id="pricing">
      <div className="wrap">
        <SectionHeading eyebrow="SIMPLE STARTS, ROOM TO GROW" title="Start small. Build when you're ready." description="Explore the right fit for your work. No card needed to see what your first workflow can do." align="center" />
        <div className="pricing-controls"><span className={!annual ? "is-selected" : ""}>Monthly</span><button type="button" className={`billing-toggle${annual ? " is-on" : ""}`} role="switch" aria-checked={annual} aria-label="Toggle annual billing" onClick={() => setAnnual(value => !value)}><span /></button><span className={annual ? "is-selected" : ""}>Annual</span><span className="savings-chip">2 months free</span></div>
        <p className="fine-print pricing-note">Placeholder prices—validate with customer interviews before launch.</p>
        <div className="pricing-grid">{plans.map(plan => {
          const computed = annual && plan.amount ? (plan.amount * 10 / 12).toFixed(2) : null;
          const href = plan.id === "free" || plan.id === "pro" ? "#start" : "#demo";
          return <article className={`price-card${plan.popular ? " price-card--popular" : ""}`} key={plan.id}>
            {plan.popular && <div className="price-card__ribbon">MOST POPULAR <span /></div>}
            <div className="price-card__head"><span className="price-card__name">{plan.name}</span><span className="price-card__for">For {plan.for}</span></div>
            <p className="price-card__description">{plan.description}</p>
            <div className="price-card__price">{computed ? <><strong>${computed}</strong><span>/ month</span></> : <><strong>{plan.price}</strong>{plan.amount !== 0 && <span>/ month</span>}</>}</div>
            {computed && <p className="price-card__billing">${(plan.amount! * 10).toFixed(0)} billed yearly</p>}
            <div className="price-card__divider" />
            <p className="price-card__includes">WHAT'S INCLUDED</p>
            <ul>{plan.features.map(feature => <li key={feature}><span><Check size={12} /></span>{feature}</li>)}</ul>
            <a className={`button ${plan.popular ? "button--primary" : "button--card"}`} href={href}>{plan.action}<ArrowUpRight size={15} /></a>
          </article>;
        })}</div>
        <div className="faq-block"><div className="faq-block__intro"><p className="eyebrow"><span /> GOOD TO KNOW</p><h3>A few helpful answers.</h3><p>Still have a question? Tell us what you're working on.</p><a className="text-link" href="#demo">Talk to our team <ArrowUpRight size={14} /></a></div><div className="faq-list">{faqItems.map((item, i) => <details className="faq-item" key={item.question} open={i === 0}><summary>{item.question}<span><ChevronDown size={16} /></span></summary><p>{item.answer}</p></details>)}</div></div>
      </div>
    </section>
  );
}

function Customers() {
  const cases = [
    { icon: Command, type: "AGENCY", metric: "[X]", unit: "hours saved", title: "More time for client work.", body: "Add the challenge, prompt, workflow built, before-and-after build time, and clients added.", quote: "Add a verified client quote here." },
    { icon: GraduationCap, type: "INSTITUTE", metric: "[X]", unit: "minutes of class time saved", title: "More strategy in every class.", body: "Add cohort size, student project outcomes, and an instructor quote.", quote: "Add a verified instructor quote here." },
    { icon: Headphones, type: "SUPPORT TEAM", metric: "[X]%", unit: "fewer repeat tickets", title: "Better help, at the moments that count.", body: "Add ticket deflection, first-response time, and satisfaction before and after.", quote: "Add verified support-team results here." },
  ];
  return (
    <section className="customers-section section-pad" id="customers">
      <div className="wrap">
        <SectionHeading eyebrow="PROOF, WITH THE DETAILS THAT MATTER" title="Good outcomes deserve good evidence." description="Add real customer stories here as pilot results come in. We’ve left the proof points intentionally open." />
        <div className="customer-grid">{cases.map((item, i) => {
          const Icon = item.icon;
          return <article className="customer-card" key={item.type}><div className="customer-card__top"><span><Icon size={15} /> {item.type}</span><span>CASE STUDY 0{i + 1}</span></div><div className="customer-card__metric"><strong>{item.metric}</strong><span>{item.unit}</span></div><h3>{item.title}</h3><p>{item.body}</p><blockquote>“{item.quote}”</blockquote><div className="customer-card__placeholder"><span /><span /> PILOT RESULT TO ADD</div></article>;
        })}</div>
        <p className="fine-print customers-note">Case-study figures and quotes are placeholders, not measured customer results.</p>
      </div>
    </section>
  );
}

function DemoForm() {
  const [submitted, setSubmitted] = useState(false);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitted(true);
  }
  return (
    <section className="demo-section section-pad" id="demo">
      <div className="wrap demo-layout">
        <div className="demo-copy"><p className="eyebrow eyebrow--light"><span /> LET'S MAKE IT CONCRETE</p><h2>Book a demo.</h2><p>Tell us a little and we will show you a workflow built from your own scenario.</p><div className="demo-promise"><span><ShieldCheck size={17} /></span><div><strong>A real scenario, not a canned deck.</strong><small>Bring the process you want to make easier.</small></div></div><div className="demo-step"><span>01</span><span>Share the repetitive work</span></div><div className="demo-step"><span>02</span><span>See a workflow take shape</span></div><div className="demo-step"><span>03</span><span>Review it together</span></div></div>
        <div className="demo-form-wrap">{submitted ? <div className="form-success" role="status"><span className="form-success__icon"><Check size={23} /></span><p className="eyebrow"><span /> THANK YOU</p><h3>Thanks for your interest.</h3><p>Your demo request is ready. This sample form is not connected to email or a CRM yet.</p><a className="text-link" href="#home">Back to the top <ArrowUpRight size={15} /></a></div> : <form className="lead-form" onSubmit={submit}><div className="lead-form__heading"><span>BOOK A DEMO</span><span>01 — 04</span></div><label>Name<input type="text" name="name" placeholder="Your name" autoComplete="name" required /></label><label>Work email<input type="email" name="email" placeholder="you@company.com" autoComplete="email" required /></label><label>You are<select name="audience" defaultValue=""><option value="" disabled>Choose the closest fit</option>{audiences.map(item => <option value={item.label} key={item.id}>{item.label}</option>)}</select></label><label>What should we automate?<textarea name="scenario" rows={3} placeholder="Tell us about the work that takes too long…" /></label><button className="button button--primary lead-form__submit" type="submit">Request demo <ArrowUpRight size={16} /></button><p className="lead-form__note"><ShieldCheck size={14} /> This form shows a thank-you state only. Email/CRM delivery must be connected before launch.</p></form>}</div>
      </div>
    </section>
  );
}

function StartFree() {
  const [audienceId, setAudienceId] = useState("");
  const [prompt, setPrompt] = useState("");
  const [email, setEmail] = useState("");
  const [generated, setGenerated] = useState(false);
  const activeAudience = audiences.find(item => item.id === audienceId);
  function changeAudience(value: string) {
    setAudienceId(value);
    const next = audiences.find(item => item.id === value);
    setPrompt(next?.prompt ?? "");
    setGenerated(false);
  }
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setGenerated(true);
  }
  const sampleSteps: WorkflowStep[] = useMemo(() => [
    { kind: "trigger", label: audienceId === "institute" ? "Student question arrives" : "Customer message arrives", detail: "Start from the request" },
    { kind: "ai", label: "Understand the request", detail: "Identify topic and urgency" },
    { kind: "ai", label: "Prepare a helpful response", detail: "Use the instructions in your prompt" },
    { kind: "human", label: "Route sensitive issues", detail: "A person reviews what needs care" },
    { kind: "result", label: "Log the conversation", detail: "Keep the outcome visible" },
  ], [audienceId]);
  return (
    <section className="start-section section-pad" id="start">
      <div className="wrap start-layout">
        <div className="start-intro"><p className="eyebrow"><span /> YOUR FIRST WORKFLOW STARTS HERE</p><h2>Build your first support workflow <em>today.</em></h2><p>No card needed. Your first generation is free.</p><div className="start-proof"><span><Check size={14} /></span>Choose a starting point, then make it yours.</div><div className="start-stamp"><div className="start-stamp__orbit"><GitBranch size={26} /></div><span>ONE SMALL<br />START CAN CHANGE<br /><strong>THE WHOLE FLOW.</strong></span></div></div>
        <div className="start-builder"><div className="start-builder__top"><span className="start-builder__brand"><span className="start-builder__spark"><Sparkles size={15} /></span> WORKFLOW BUILDER</span><span className="start-builder__step">STEP 01 <i /> 03</span></div>
          {!generated ? <form className="builder-form" onSubmit={submit}>
            <label className="builder-field"><span>01 / WHO ARE YOU BUILDING FOR?</span><select required value={audienceId} onChange={event => changeAudience(event.target.value)}><option value="" disabled>Choose your starting point</option>{audiences.map(item => <option value={item.id} key={item.id}>{item.label}</option>)}</select></label>
            <label className="builder-field"><span>02 / DESCRIBE THE WORK</span><textarea required rows={5} value={prompt} onChange={event => { setPrompt(event.target.value); setGenerated(false); }} placeholder="Tell PromptFlow what should happen, when, and who should step in…" /></label>
            <label className="builder-field"><span>03 / YOUR WORK EMAIL</span><input type="email" required value={email} onChange={event => setEmail(event.target.value)} placeholder="Your work email" autoComplete="email" /></label>
            <button className="button button--primary builder-submit" type="submit">Generate my workflow <ArrowUpRight size={16} /></button>
            <p className="builder-note"><ShieldCheck size={14} /> A sample appears here. This preview does not send email or call a live AI service.</p>
          </form> : <div className="builder-result" role="status"><div className="builder-result__success"><span><Check size={16} /></span><div><strong>Your sample workflow is ready.</strong><small>Sample preview for {activeAudience?.short.toLowerCase()}.</small></div></div><div className="builder-result__body"><div className="builder-result__prompt"><span><Command size={13} /> YOUR PROMPT</span><p>{prompt}</p></div><WorkflowPreview steps={sampleSteps} title="Sample support workflow" subtitle="Preview · not deployed" compact /></div><button className="builder-edit" type="button" onClick={() => setGenerated(false)}>Edit your prompt <ArrowRight size={14} /></button><p className="builder-note"><ShieldCheck size={14} /> Illustrative sample only. Review and test before any real deployment.</p></div>}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="footer-main"><div className="footer-brand-block"><Brand inverse /><p>Describe the work.<br />Review every step.</p><span className="footer-brand-block__note">A friendlier way to build customer support workflows.</span></div><div className="footer-links"><div><h3>PRODUCT</h3><a href="#how">How it works</a><a href="#support">Support automation</a><a href="#templates">Templates</a><a href="#pricing">Pricing</a></div><div><h3>FOR YOUR WORK</h3><a href="#solutions">Agencies</a><a href="#solutions">Institutes</a><a href="#solutions">Freelancers</a><a href="#solutions">Support teams</a></div><div><h3>LET'S TALK</h3><a href="#customers">Customers</a><a href="#demo">Book a demo</a><a href="#start">Start free <ArrowUpRight size={13} /></a><a href="#prelaunch">Before launch</a></div></div></div>
        <div className="footer-launch" id="prelaunch"><span className="footer-launch__tag"><CircleHelp size={15} /> BEFORE LAUNCH</span><p>Add privacy, terms, and security pages. Connect forms to email/CRM, verify prices and pilot results, and confirm the integration list.</p></div>
        <div className="footer-bottom"><span>© 2026 PromptFlow. Brand name is a placeholder; replace before launch.</span><span>BUILT AROUND BETTER WORKFLOWS <i /> HUMAN REVIEW INCLUDED</span></div>
      </div>
    </footer>
  );
}

export default function Home() {
  return <div className="site-shell"><a className="skip-link" href="#main-content">Skip to content</a><Header /><main id="main-content"><Hero /><Comparison /><ThreeSteps /><SupportAutomation /><Solutions /><Templates /><Pricing /><Customers /><DemoForm /><StartFree /></main><Footer /></div>;
}
