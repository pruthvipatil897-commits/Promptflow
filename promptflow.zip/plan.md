# PromptFlow Website — Implementation Plan

## Product scope and implementation approach

Build a polished, responsive website from the supplied `PromptFlow_Website_Content_and_Structure.docx`. The document is the content source of truth. The site will present the listed destinations as a navigable, long-form section experience using the brief's own anchor addresses: Home, How it works, Support automation, Solutions, Templates, Pricing, Customers, Book a demo, and Start free. This fits the supplied sitemap while keeping discovery and the primary conversion path in one coherent flow.

Use the initialized React 19 + TypeScript + Vite starter and its static frontend runtime. No authentication, server, database, or external CRM/email integration is needed for the supplied marketing-site behavior. Use local data and state for the scenario tabs, template filters, annual pricing toggle, mobile menu, and sample workflow generation. The demo form will show the document's requested thank-you state; the free-start flow will display an illustrative generated workflow. Make those demonstrations clearly client-side samples, not live AI generation or lead delivery. Preserve every supplied price, time comparison, workflow prompt and step, plan feature, FAQ, audience use case, integration caveat, and non-production placeholder without presenting illustrative metrics as verified results.

The Home hero will carry the main signature interaction: an editable-looking prompt card beside a connected workflow preview, with a restrained type-on/reveal animation. The Support automation section will offer four selectable scenarios (Instant replies, Escalate complaints, Refunds, Satisfaction survey), each paired with its original prompt and five-step flow. Steps use an outlined treatment for triggers/results, teal for AI steps, and amber for human checkpoints. Templates filter by All, Support, Agency, and Education. Pricing has monthly/annual controls with the brief's two-months-free convention. The start flow offers the four audience-specific prefilled prompts and renders a sample workflow after submission.

Maintain one shared visual system across sections, with clear calls to action, semantic forms and labels, visible focus states, accessible contrast, responsive navigation, system-preference dark mode, and reduced-motion support. Use only relative browser-facing links. The footer will surface the privacy, terms, security, and integration-confirmation items that the brief says must be addressed before launch, and list the additional future pages without implying that they already exist.

## Design direction

- **Design Movement:** Contemporary editorial SaaS—quietly confident product craft, warm paper surfaces, and precise interface details rather than generic neon AI styling.
- **Core Principles:** (1) Explain the product in seconds. (2) Make every automation legible and reviewable. (3) Keep human judgment visible at sensitive moments. (4) Make the next step feel low-risk and easy.
- **Color Philosophy:** Choose a friendly, nature-grounded palette that feels dependable without the coldness of default enterprise blue. Use warm ivory (`#F7F8F4`) and soft stone (`#E9EEE8`) as calm canvases; deep ink (`#18313A`) for confident text and dark surfaces; evergreen/teal (`#16796B`) as the ownable action color; and soft amber (`#D99A44`) to make human review unmistakable. In dark mode, use deep green-charcoal (`#101D20`), lifted slate surfaces (`#1B2B2D`), brighter mint-teal (`#55C4AA`), and warm gold (`#F0BD69`). Keep text contrast high and reserve amber for checkpoints, warnings, and small emphasis.
- **Layout Paradigm:** A flowing product narrative rather than a stack of identical cards: an asymmetric two-column hero; a full-width dark workflow demonstration; alternating editorial comparison and explainer bands; scenario tabs beside a vertical workflow; audience-specific solution panels; and compact conversion sections. Keep content within a comfortable ~1140px measure and allow the workflow preview to break out visually.
- **Signature Elements:** (1) Connected workflow rails and node markers that visually link prompt to outcome. (2) A small amber human-review node and amber “human in the loop” chip. (3) A folded-corner/angled button edge echoed in prompt and workflow panels.
- **Interaction Philosophy:** Every control previews a real consequence in the interface: tabs replace prompt/steps, filters narrow the template library, pricing controls update displayed amounts, and forms return clear inline success states. Avoid hidden or surprise transitions; label sample/demo behavior explicitly.
- **Animation:** One restrained hero typing/reveal moment, with a pause/skip-safe final state; short opacity/translate transitions for section content and interactive controls; no scroll-jacking, parallax, or looping decoration. Use CSS/React motion sparingly and disable non-essential motion under `prefers-reduced-motion: reduce`.
- **Typography System:** Bricolage Grotesque for expressive, compact headlines; Figtree for highly readable body text at approximately 17px with generous line-height; IBM Plex Mono for prompts, labels, and workflow metadata. Establish a fluid display scale with tight headline tracking, clear section-title hierarchy, and readable 16–18px body copy.
- **Brand Essence:** Plain-language automation for small teams and service businesses—describe the work, inspect every step, and keep control before launch. Personality: **clear, capable, considerate**.
- **Brand Voice:** Direct and practical, with human control emphasized; CTA copy is specific about the next action and never implies a live integration unless configured. Examples: “Describe the work. Review every step.” and “Try a sample workflow—no card needed.”
- **Wordmark & Logo:** A custom “PromptFlow” wordmark paired with a compact branching-flow glyph: one rounded input node splitting into two paths that reconnect at a small review point. Render as an inline vector/CSS mark and create a matching project logo asset for platform metadata.
- **Signature Brand Color:** Evergreen teal (`#16796B`), used consistently for primary actions, active states, and the AI-step legend.

## Project structure

- `client/src/App.tsx` — top-level theme and page composition.
- `client/src/pages/Home.tsx` — anchor destinations, section order, and cross-section site experience.
- `client/src/components/site/` — small reusable site modules: wordmark/navigation, section headings, workflow preview, scenario selector, template cards/filters, pricing cards, FAQ, lead/start forms, and footer.
- `client/src/index.css` — brand tokens, light/dark system modes, typography, responsive layout, focus states, reduced-motion behavior, and component styling.
- `client/index.html` — document title, description, and site metadata.
- `client/public/manus-routes.json` — route manifest for the one `/` page; section links remain in-page anchors.
- `client/public/` — favicon and any local brand assets.
- `app.config.ts` — literal durable HTTPS logo URL for project branding metadata.
- `plan.md` and `TODO.md` — approved implementation direction and complete outcome clauses.

## Delivery constraints

The document identifies PromptFlow as a placeholder brand, the monthly prices and case-study results as unvalidated, the Home comparison as illustrative, and form delivery as not connected to email/CRM. The implementation will keep these caveats explicit and will not invent customer outcomes, integrations, or submission backends. Blog, Webinars, Help Centre, Partners, About, Contact, Privacy, Terms, and Security remain launch/future content items rather than fabricated pages.